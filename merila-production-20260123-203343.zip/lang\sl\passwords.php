<?php

return [

    'reset' => 'Vaše geslo je bilo ponastavljeno.',
    'sent' => 'Poslali smo vam povezavo za ponastavitev gesla.',
    'throttled' => 'Počakajte, preden poskusite znova.',
    'token' => 'Ta žeton za ponastavitev gesla ni veljaven.',
    'user' => 'Ne moremo najti uporabnika s tem e-poštnim naslovom.',

];
