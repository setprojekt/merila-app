<?php

return [

    'failed' => 'Ti podatki se ne ujemajo z našimi zapisi.',
    'password' => 'Navedeno geslo ni pravilno.',
    'throttle' => 'Preveč poskusov prijave. Poskusite znova čez :seconds sekund.',

];
