<?php

return [

    'previous' => '&laquo; Prejšnja',
    'next' => 'Naslednja &raquo;',

];
