<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// Email scheduler - pošlji opozorila vsak dan ob 08:00
Schedule::command('instruments:send-reminders')
    ->dailyAt('08:00')
    ->timezone('Europe/Ljubljana');

// Activity Log cleanup - počisti stare zapise enkrat na mesec
Schedule::command('activitylog:cleanup --months=6')
    ->monthly()
    ->timezone('Europe/Ljubljana');
